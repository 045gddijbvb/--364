<?php
    include 'functions.php';
    $filename = 'products.ini';
    $products = load_products_from_ini($filename);
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Товары</title>
    <link rel="stylesheet" href="/css/styles.css">
</head>
<body>
    <header>
        <h1>Товары</h1>
    </header>
    <div class='box'>
        <?php display_all_products($products); ?>
    </div>
</body>
</html>