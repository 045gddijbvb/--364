<link rel="stylesheet" href="/css/styles.css">
<?php
function display_product_card($product) {
        echo '<div style="border: 1px solid #ddd; padding: 15px; margin: 10px; width: 300px;cursor: pointer;">';
        echo '<h2>' . htmlspecialchars($product['name']) . '</h2>';
        echo '<p><strong>ID:</strong> ' . htmlspecialchars($product['id']) . '</p>';
        echo '<p><strong>Описание:</strong> ' . htmlspecialchars($product['description']) . '</p>';
        echo '<p><strong>Цена:</strong> ' . htmlspecialchars($product['price']) . ' р.</p>';
        echo '<p><strong>Кол-во на складе:</strong> ' . htmlspecialchars($product['stock']) . '</p>';
        echo '</div>';
    }
    function load_products_from_ini($filename) {
        if (!file_exists($filename)) {
        }
        return parse_ini_file($filename, true);
    }
    function display_all_products($products) {
        foreach ($products as $product) {
            display_product_card($product);
        }
    }
?>